<?php $__env->startSection('plan_add'); ?>
<?php if(count($errors) > 0): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<div class="card">
  <div class="card-body">
    <h4 class="card-title">企画作成</h4>
    <form action="<?php echo e(route('plan_create')); ?>" method="post">
      <?php echo e(csrf_field()); ?>

      <div class="form-group">
        <label for="kikakumei">企画名</label>
        <div class="col-sm-10">
          <input type="text" class="form-control" id="kikakumei" placeholder="企画名" name="planName">
        </div>
      </div>
      <div class="form-group">
        <label for="kikakusetumei">企画説明</label>
        <div class="col-sm-10">
          <input type="text" class="form-control" id="kikakusetumei" placeholder="企画説明" name="planDescription">
        </div>
      </div>
      <div class="form-group">
        <label for="sakuseisyamei">作成者名</label>
        <div class="col-sm-10">
          <input type="text" class="form-control" id="sakuseisyamei" placeholder="作成者名" name="createUser">
        </div>
      </div>
      <div class="form-group">
        <label for="sakuseisyamei">編集キー</label>
        <div class="col-sm-10">
          <input type="text" class="form-control" id="sakuseisyamei" placeholder="編集キー" name="editKey">
        </div>
      </div>
      <input type="submit" value="投稿">
    </form>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('...layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>